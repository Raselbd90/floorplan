"""
Floor Plan Generator Script
""" 
print("Welcome to the Floor Plan Generator!")